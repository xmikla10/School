package ija.ija2016.othello.game.ai;

import ija.ija2016.othello.board.AbstractField;
import ija.ija2016.othello.board.Board;
import ija.ija2016.othello.game.IOthelloField;
import ija.ija2016.othello.game.AbstractPlayer;

/**
 * Created by david on 13.4.16.
 */
public interface AI {
    void nextMove(Board board);

    static AbstractField computeHintMove(AbstractPlayer player, Board board) {
        IOthelloField f = board.getGameFields().stream().
                filter(player::canPutDisk).
                max((x, y) ->
                        Integer.compare(
                                x.countChangedDisks(player.isWhite()),
                                y.countChangedDisks(player.isWhite()))).
                get();

        return (AbstractField) f;
    }
}
