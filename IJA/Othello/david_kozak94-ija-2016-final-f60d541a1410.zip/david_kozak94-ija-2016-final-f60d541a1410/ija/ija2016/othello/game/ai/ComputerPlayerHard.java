package ija.ija2016.othello.game.ai;

import ija.ija2016.othello.board.Board;
import ija.ija2016.othello.game.IOthelloField;
import ija.ija2016.othello.game.AbstractPlayer;

/**
 * Created by david on 13.4.16.
 */
public class ComputerPlayerHard extends AbstractPlayer implements AI {

    public ComputerPlayerHard(boolean isWhite) {
        super(isWhite);
    }


    @Override
    public void nextMove(Board board) {
        IOthelloField f = board.getGameFields().stream().filter(super::canPutDisk).max((x,y)->
                Integer.compare(x.countChangedDisks(isWhite),y.countChangedDisks(isWhite))).get();

        super.putDisk(f);

    }
}
