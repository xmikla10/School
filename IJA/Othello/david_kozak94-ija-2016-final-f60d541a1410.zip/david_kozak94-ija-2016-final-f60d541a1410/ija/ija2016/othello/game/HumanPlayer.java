package ija.ija2016.othello.game;


/**
 * Created by david on 24.3.16.
 */
public class HumanPlayer extends AbstractPlayer {

    public HumanPlayer(boolean isWhite) {
        super(isWhite);
    }
}
