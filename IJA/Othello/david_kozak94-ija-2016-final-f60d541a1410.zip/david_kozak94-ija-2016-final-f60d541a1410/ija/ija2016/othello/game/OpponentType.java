package ija.ija2016.othello.game;

/**
 * Created by david on 15.4.16.
 */
public enum OpponentType {
    human,
    pc_easy,
    pc_hard
}
