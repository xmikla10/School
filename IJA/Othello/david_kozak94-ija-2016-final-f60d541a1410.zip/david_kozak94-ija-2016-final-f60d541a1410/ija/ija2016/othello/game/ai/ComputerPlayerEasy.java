package ija.ija2016.othello.game.ai;

import ija.ija2016.othello.board.Board;
import ija.ija2016.othello.board.Field;
import ija.ija2016.othello.game.AbstractPlayer;

import java.util.List;
import static java.util.stream.Collectors.toList;

/**
 * Created by david on 13.4.16.
 */
public class ComputerPlayerEasy extends AbstractPlayer implements AI  {

    public ComputerPlayerEasy(boolean isWhite){
        super(isWhite);
    }

    @Override
    public void nextMove(Board board) {
        List<Field> f = board.getGameFields().stream().
                filter(super::canPutDisk)
                .collect(toList());

        super.putDisk(f
                .get(0));
    }
}
