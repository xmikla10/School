package ija.ija2016.othello.game;

import ija.ija2016.othello.board.Disk;
import ija.ija2016.othello.board.Field;

/**
 * Created by david on 13.4.16.
 */
public interface IOthelloField extends Field {
    int countChangedDisks(Boolean isWhite);

    boolean isFrozen();
    void setFrozen(boolean frozen);
    Disk forceGetDisk();
}
