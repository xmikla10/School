package ija.ija2016.othello.game;

import ija.ija2016.othello.board.BorderField;
import ija.ija2016.othello.board.Field;
import ija.ija2016.othello.board.Rules;

/**
 * Created by david on 24.3.16.
 */
public class ReversiRules implements Rules{
    private int size;

    public ReversiRules(int size) {
        this.size = size;
    }

    @Override
    public Field createField(int row, int col) {
        if(row == 0 || col == 0 || row == size + 1 || col == size + 1)
            return new BorderField();
        else
            return new BoardField(row,col);
    }

    @Override
    public int getSize() {
        return size;
    }

    @Override
    public int numberDisks() {
        return size*size  / 2;
    }
}
