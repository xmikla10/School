package ija.ija2016.othello.gui;

import java.awt.*;

/**
 * Created by david on 14.4.16.
 */
public interface MainWindowCallback {

    /**
     * end the game
     * @param isWhite indicates winner, true==white
     */
    void endGame(boolean isWhite,Point score);
    void updateInfoField(String s);
    void updateScoreField(Point score);
    void repaint();
}
