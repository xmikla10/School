package ija.ija2016.othello;

/**
 * Created by david on 15.4.16.
 */
public class LogProducer {
    public static void info(Loggable l,String msg) {
        System.out.println("INFO class=" + l.getTag() + " msg=" + msg);
    }

    public interface Loggable{
        String getTag();
    }
}
