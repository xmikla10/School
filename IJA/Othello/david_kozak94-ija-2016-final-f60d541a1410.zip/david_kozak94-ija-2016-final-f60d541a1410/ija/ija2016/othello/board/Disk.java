package ija.ija2016.othello.board;

import java.io.Serializable;

/**
 * Created by david on 24.3.16.
 */
public class Disk implements Serializable{
    private boolean isWhite;

    public Disk(boolean isWhite) {
        this.isWhite = isWhite;
    }

    public boolean isWhite() {
        return isWhite;
    }

    public void turn() {
        this.isWhite = !this.isWhite;
    }
}
