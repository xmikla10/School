package ija.ija2016.othello.board;

import java.io.Serializable;

/**
 * Created by david on 24.3.16.
 */
public interface Field extends GameMoveLogic,Serializable {
    enum Direction {
        D, L, LD, LU, R, RD, RU, U
    }

    void addNextField(Direction dirs,Field field);
    boolean canPutDisk(Disk disk);
    Disk getDisk();
    boolean isEmpty();
    Field nextField(Direction dirs);
    boolean putDisk(Disk disk);
    void removeDisk();
}
