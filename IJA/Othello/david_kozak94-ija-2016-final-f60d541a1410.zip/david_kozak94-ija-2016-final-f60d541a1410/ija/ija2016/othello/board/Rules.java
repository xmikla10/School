package ija.ija2016.othello.board;


import java.io.Serializable;

/**
 * Created by david on 24.3.16.
 */
public interface Rules extends Serializable{
    Field createField(int row, int col);
    int getSize();
    int numberDisks();
}
