#!/bin/bash
zip -r  xkozak15.zip ./ija ./doc build.xml
