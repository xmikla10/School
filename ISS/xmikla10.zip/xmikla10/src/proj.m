% Projekt ISS
% Autor: xmikla10

iptsetpref('UseIPPL',false);
IMG = imread('xmikla10.bmp');

%--------------------------------------------------
% zaostrenie obrazu

vysledok = 'step1.bmp';
matica1 = [-0.5 -0.5 -0.5; -0.5 5.0 -0.5; -0.5 -0.5 -0.5];
IMG1 = imfilter(IMG, matica1);
imwrite(IMG1, vysledok); %ulozenie obrazku

%--------------------------------------------------

% preklopenie obrazku okolo zvislej osy
vysledok = 'step2.bmp';
IMG2 = fliplr(IMG1);
imwrite(IMG2, vysledok); 

%--------------------------------------------------

% medianovy filter
vysledok = 'step3.bmp';
IMG3 = medfilt2(IMG2, [5 5]);
imwrite(IMG3, vysledok);

%--------------------------------------------------- 
% rozmazanie obrazu

vysledok = 'step4.bmp';
matica2 = [1 1 1 1 1; 1 3 3 3 1; 1 3 9 3 1; 1 3 3 3 1; 1 1 1 1 1] / 49;
IMG4 = imfilter(IMG3, matica2);
imwrite(IMG4, vysledok);

%--------------------------------------------------- 
% chyba v obraze

IMGporovnavanie = fliplr(IMG);
IMGold = double(IMGporovnavanie);
IMGnew = double(IMG4);
chyba = 0;
for (x = 1:512)
    for (y = 1:512)
        chyba = chyba + (abs(IMGold(x,y) - IMGnew(x,y)));
    end;
end;
chyba = chyba/512/512

%--------------------------------------------------- 
% roztiahnutie histogramu

vysledok = 'step5.bmp';

IMG4 = im2double(IMG4);
    x = min(min(im2double(IMG4)));
    y = max(max(im2double(IMG4)));
IMG5 = imadjust(IMG4, [x y], [0 1]);
IMG4 = im2uint8(IMG4);
IMG5 = im2uint8(IMG5);

imwrite(IMG5, vysledok);

%--------------------------------------------------- 
% stredne hodnoty a odchylky

IMG4 = double(IMG4);
IMG5 = double(IMG5);
mean_no_hist = mean2(im2double(IMG4))
std_no_hist = std2(im2double(IMG4))
mean_hist = mean2(im2double(IMG5))
std_hist = std2(im2double(IMG5))

%--------------------------------------------------- 
% kvantizace obrazu

vysledok = 'step6.bmp';
N = 2;
a = 0;
b = 255;
c = size(IMG5);
for (j = 1:c(1))
    for (k = 1:c(2))
        IMG6(j,k) = round(((2^N)-1)*(IMG5(j,k)-a)/(b-a))*(b-a)/((2^N)-1) + a;
    end;
end;
IMG6 = uint8(IMG6);
imwrite(IMG6, vysledok);