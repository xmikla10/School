#!/usr/bin/env bash

TASK=jsn
INTERPRETER="php -d open_basedir=\"\""
EXTENSION=php

LOCAL_IN_PATH="./" # (simple relative path)
LOCAL_IN_PATH2="" #Alternative 1 (primitive relative path)
LOCAL_IN_PATH3=`pwd`"/" #Alternative 2 (absolute path)
LOCAL_OUT_PATH="./" # (simple relative path)
LOCAL_OUT_PATH2="" #Alternative 1 (primitive relative path)
LOCAL_OUT_PATH3=`pwd`"/" #Alternative 2 (absolute path)
# cesta pro ukládání chybového výstupu studentského skriptu
LOG_PATH="./"

# invalid format of input file
# Expected return code: 2
$INTERPRETER $TASK.$EXTENSION --input=${LOCAL_IN_PATH}jsn/test00.json 
echo -n $? > test01.err

# invalid content on first line
# Expected return code: 2
$INTERPRETER $TASK.$EXTENSION --input=${LOCAL_IN_PATH}jsn/test01.jsn 
echo -n $? > test02.err

# invalid content on last line
# Expected return code: 2
$INTERPRETER $TASK.$EXTENSION --input=${LOCAL_IN_PATH}jsn/test02.jsn 
echo -n $? > test03.err

# unallowed options
# Expected return code: 1
$INTERPRETER $TASK.$EXTENSION -chleba -sunka -pepsi="cola"
echo -n $? > test04.err

# help
# Expected file: help.txt contains usage msg
# Expected return code: 0
$INTERPRETER $TASK.$EXTENSION --help > ${LOCAL_OUT_PATH3}help.txt
echo -n $? > test05.err

# help + other option
# Expected return code: 1
$INTERPRETER $TASK.$EXTENSION --help -r="root" -n
echo -n $? > test06.err

# input from stdin, output to stdout, root-element
# Expected file: ref-out/test07.xml
# Expected return code: 0
$INTERPRETER $TASK.$EXTENSION < ${LOCAL_IN_PATH2}jsn/test03.jsn > ${LOCAL_OUT_PATH2}test07.xml -r="root"
echo -n $? > test07.err

# output to stdout, item-name, root-element, array-name
# Expected file: ref-out/test08.xml
# Expected return code: 0
$INTERPRETER $TASK.$EXTENSION --input=${LOCAL_IN_PATH2}jsn/test03.jsn > ${LOCAL_OUT_PATH2}test08.xml -r="žšš" --item-name="ITEM" --array-name="ARRAY"
echo -n $? > test08.err

# index is not a number
# Expected return code: 1
$INTERPRETER $TASK.$EXTENSION --input=${LOCAL_IN_PATH2}jsn/test03.jsn --start="ABC" -t
echo -n $? > test09.err

# index is out of range
# Expected return code: 1
$INTERPRETER $TASK.$EXTENSION --input=${LOCAL_IN_PATH2}jsn/test03.jsn --start="-1" -t
echo -n $? > test010.err

# input from stdin, start without index-items / t
# Expected return code: 1
$INTERPRETER $TASK.$EXTENSION < ${LOCAL_IN_PATH2}jsn/test03.jsn --start="2" 
echo -n $? > test11.err

# input from stdin, h s i l root-element
# Expected file: ref-out/test12.xml
# Expected return code: 0
$INTERPRETER $TASK.$EXTENSION < ${LOCAL_IN_PATH2}jsn/test04.jsn --output=${LOCAL_IN_PATH2}test12.xml -h="ABC" -s -i -l -r="OpieOP"
echo -n $? > test12.err

# h root-element
# Expected return code: 0
$INTERPRETER $TASK.$EXTENSION --input=${LOCAL_IN_PATH2}jsn/test05.jsn --output=${LOCAL_IN_PATH2}test13.xml -h="VUT" -r="rôôt"
echo -n $? > test13.err

# duplicated root-element
# Expected return code: 1
$INTERPRETER $TASK.$EXTENSION -r="rôôt" -r="róót" -r="root"
echo -n $? > test14.err

# t start array-name item-name root-element
# Expected file: ref-out/test15.xml
# Expected return code: 0
$INTERPRETER $TASK.$EXTENSION --input=${LOCAL_IN_PATH2}jsn/test06.jsn --output=${LOCAL_IN_PATH2}test15.xml -h="SUB_" -t --start="15" -r="ROOT" --array-name="yarra" --item-name="meti"
echo -n $? > test15.err