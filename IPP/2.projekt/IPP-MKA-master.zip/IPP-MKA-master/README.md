# IPP MKA Testovací sada
IPP: Projekt - úloha MKA (Minimalizace konečného automatu)

Toto je původně script pro testování úlohy SYN, který vytvořil Granát Štěpán. 
Provedl jsem pouze drobné úpravy pro testování úlohy MKA a přidal referenční testy od vyučujících (pro přehlednost) 
a nějaké další testy co mě napadly.
Testy na rozšíření nejsou zahrnuty.

# Zprovoznění

1. Zkopíruj si obsah repozitáře do adresáře se svým skriptem
2. V souboru test.sh stačí nastavit proměnnou TASK na název svého scriptu (výchozí je mka)
3. Spusť ve složce se souborem test.sh příkazem sh test.sh

Pokud najdeš chybu, piš sem: https://www.fb.com/groups/fitbit2013/permalink/417830305054775/
